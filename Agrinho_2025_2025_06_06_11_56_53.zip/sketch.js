function setup() {
  createCanvas(800, 600);
}

function draw() {
  background("rgb(65,65,126)"); // Céu azul
  
  text ("⭐", 450, 150)
  text ("⭐", 500, 100)
  text ("⭐", 600, 110) 
  text ("⭐", 700, 110) 
  text ("⭐", 750, 170) 
  text ("⭐", 140, 160) 
  text ("⭐", 200, 150) 
  text ("⭐", 230, 210) 
  text ("⭐", 30,110)
  text ("⭐", 90, 140)
  text ("⭐", 70, 100)
  text ("🌙", 400, 80)
        
    
  
  // Campo verde
  fill(34, 139, 34);
  noStroke();
  rect(0, height * 0.75, width, height * 0.25);

  // Árvores
  drawTree(150, height * 0.75);
  drawTree(300, height * 0.75);
  drawTree(450, height * 0.75);
  drawTree(600, height * 0.75);

  // Cidade ao fundo
  drawCity();
}

function drawTree(x, y) {
  // Tronco
  fill(139, 69, 19);
  rect(x, y - 50, 20, 50);
  // Folhagem
  fill(34, 139, 34);
  ellipse(x + 10, y - 70, 60, 60);
}

function drawCity() {
  fill(169, 169, 169);
  // Prédios
  rect(100, height * 0.5, 50, height * 0.25);
  rect(200, height * 0.45, 70, height * 0.3);
  rect(320, height * 0.55, 60, height * 0.2);
  rect(420, height * 0.5, 80, height * 0.25);
  rect(550, height * 0.4, 100, height * 0.35);
  rect(700, height * 0.55, 50, height * 0.2);
  
   
  }




